import {useEffect, useState} from "react";
export default function Flights() {
    const [flights, setFlights] = useState(null);

    useEffect(() => {
        fetch('./2.php.json')
            .then(response => response.json())
            .then(response =>  setFlights(response))
            .catch(err => console.error('Ошибка:', err));
    }, []);


    // const handleBookFlight = (flightId) => {
    //     setFlights((prevFlights) =>
    //         prevFlights.map((flight) =>
    //             flight.flight_number === flightId
    //                 ? { ...flight, seats_available: Math.max(0, flight.seats_available - 1) }
    //                 : flight
    //         )
    //     );
    // };

    return (
        <main>
            <section className="gagarin-info">
                <div className="container">
                    <div className="row">
                        <div className="col-md-6 col-sm-12 gagarin-img">
                            <img src="/img/67c9e921661452cf8ad11cde7a8124c0.jpeg"/>
                        </div>
                        <div className="col-md-6 col sm-12">
                            <h1>Список космических рейсов</h1>
                            {!flights ? (
                                <p>Загрузка...</p>
                            ) : ( flights.data.map(flight => (
                                <div className="booking-flight" key={flight.name}>
                                    <div className="number">{flight.flight_number}</div>
                                    <div className="arrival">{flight.destination}</div>
                                    <div className="date">{flight.launch_date}</div>
                                    <div className="amount">{flight.seats_available}</div>
                                    <a href="#" className="btn btn-primary" disabled={flight.seats_available === 0}>Записаться</a>
                                </div>
                            )))}
                            <a href="#" className="btn btn-primary">Добавить рейс</a>
                            <a href="#" className="btn btn-secondary">На главную</a>
                        </div>
                    </div>
                </div>
            </section>
        </main>
    )
}