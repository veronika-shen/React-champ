import {useEffect, useState} from "react";
export default function Mission() {
    const [missions, setMissions] = useState(null);

    useEffect(() => {
        fetch('./1.php.json')
            .then(response => response.json())
            .then(response =>  setMissions(response.map(m => m.mission)))
            .catch(err => console.error('Ошибка:', err));
    }, []);


    return (
        <main>
            <section className="gagarin-info">
                <div className="container">
                    <div className="row">
                        <div className="col-md-6 col-sm-12 gagarin-img">
                            <img src="/img/c89cfefaba0247d8a21e071e318b57d2.jpeg"/>
                        </div>
                        <div className="col-md-6 col sm-12">
                            <h1>Миссии</h1>
                            {!missions ? (
                                <p>Загрузка...</p>
                            ) : (
                                missions.map(mission => (
                                    <div className="flight" key={mission.name}>
                                        <h2>{mission.name}</h2>
                                        <h3>{mission.launch_details.launch_site.name}</h3>
                                        <p>Дата запуска: <span className="birthday">{mission.launch_details.launch_date}</span></p>
                                        <h3>Миссия:</h3>
                                        <div className="">
                                            <p className="pilot">{mission.landing_details.landing_site.name}</p>
                                            <p className="small">{mission.landing_details.landing_date}</p>
                                        </div>
                                        <h4>Командный модуль</h4>
                                        <p>Колумбия</p>
                                        <h4>Лунный модуль</h4>
                                        <p>Орел</p>
                                        <h3>Члены экипажа:</h3>
                                        <div className="">
                                            <p className="pilot">Нил Армстронг</p>
                                            <p className="small">Командир</p>
                                            <p className="pilot">Базз Олдрин</p>
                                            <p className="small">Пилот лунного модуля</p>
                                            <p className="pilot">Майкл Коллинз</p>
                                            <p className="small">Пилот командного модуля</p>
                                        </div>

                                    </div>
                                    )
                                ))}

                            </div>
                        </div>
                    </div>
            </section>
        </main>
    )
}