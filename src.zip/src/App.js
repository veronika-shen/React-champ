import Header from "./components/Header"
import Main from "./components/Main"
import Footer from "./components/Footer"
import {Route, Routes} from "react-router-dom";
import Mission from "./components/Missions/Mission";
import Flights from "./components/Flights/Flights";


export default function App() {
  return(
    <>
      <Header />
      <Routes>
          <Route path='/main' element={<Main />}/>
          <Route path='/missions' element={<Mission/>}/>
          <Route path='/flights' element={<Flights />}/>
      </Routes>
      <Footer/>
    </>
  )
}