import {Link} from "react-router-dom";

export default function Main(){
    return(
        <main>
        <section class="gagarin-info">
            <div class="container">
                <div class="row">
                    <div class="col-md-6 col-sm-12 gagarin-img">
                        <img src="https://interesnyefakty.org/wp-content/uploads/Foto-YUriya-Gagarina-8.jpg" />
                    </div>
                    <div class="col-md-6 col sm-12">
                        <h1>Юрий Гагарин</h1>
                        <p class="birthday">1934-03-09</p>
                        <p class="rank">Старший лейтенант</p>
                        <div class="bio">
                            <p>Родился в Клушино, Россия.</p>
                            <p>Отобран в отряд космонавтов в 1960 году...</p>
                            <p>Стал международным героем</p>
                        </div>
                        <Link to='/missions'>К списку миссий</Link>
                    </div>
                </div>
            </div>
        </section>
    </main>
    );
}